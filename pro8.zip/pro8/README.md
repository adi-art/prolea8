# Line-py-by-Fadhiilrachman
Forked, inspirasi dari TCR

Requirement

The linepy module only requires Python 2.7, or Python 3.

Installation

--> pip install linepy
Atau
--> python setup.py install

*Tambahan

--> pip install linepy --upgrade

Open Folder Examples:

--> python3 Line-TCR.py

Author @ Fadhiil Rachman / (https://www.instagram.com/fadhiilrachman/)

Spesial Thanks
--> carpedm20 = https://github.com/carpedm20
--> Matti Virkkunen = https://github.com/mvirkkunen
